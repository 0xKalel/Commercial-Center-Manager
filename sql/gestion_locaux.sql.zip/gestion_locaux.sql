-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: custsql-ipg23.eigbox.net
-- Généré le : Mercredi 23 Mars 2016 à 06:52
-- Version du serveur: 5.5.44
-- Version de PHP: 4.4.9
-- 
-- Base de données: `gestion_locaux`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `admin`
-- 

CREATE TABLE `admin` (
  `nom` varchar(100) COLLATE hp8_bin NOT NULL,
  `mot_de_passe` varchar(100) COLLATE hp8_bin NOT NULL,
  `type` varchar(10) COLLATE hp8_bin NOT NULL,
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=hp8 COLLATE=hp8_bin;

-- 
-- Contenu de la table `admin`
-- 

INSERT INTO `admin` VALUES (0x6261646f75, 0x6261646f75, 0x7072696e636970616c);
INSERT INTO `admin` VALUES (0x68616d616461, 0x68616d616461, 0x707269636970616c);
INSERT INTO `admin` VALUES (0x68616d6964, 0x68616d6964, 0x7072696e636970616c);
INSERT INTO `admin` VALUES (0x6b68616c696c, 0x6b68616c696c, 0x617373697374616e74);
INSERT INTO `admin` VALUES (0x6d6f6e646572, 0x6d6f6e646572, 0x617373697374616e74);

-- --------------------------------------------------------

-- 
-- Structure de la table `contrats`
-- 

CREATE TABLE `contrats` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `local` int(255) NOT NULL,
  `locataire` int(255) NOT NULL,
  `date` varchar(10) COLLATE hp8_bin NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `montant` int(200) NOT NULL,
  `autre_declaration` int(100) DEFAULT NULL,
  `fichier` varchar(250) COLLATE hp8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=hp8 COLLATE=hp8_bin AUTO_INCREMENT=189 ;

-- 
-- Contenu de la table `contrats`
-- 

INSERT INTO `contrats` VALUES (167, 1, 1, 0x30342f30322f32303136, '2016-02-15', '2017-02-15', 214, 0, '');
INSERT INTO `contrats` VALUES (168, 154, 46, 0x31382f30322f32303136, '2016-02-18', '2017-02-18', 25000, 0, '');
INSERT INTO `contrats` VALUES (169, 155, 47, 0x32322f31322f32303135, '2016-01-29', '2017-01-29', 20000, 0, '');
INSERT INTO `contrats` VALUES (170, 141, 49, 0x32372f30382f32303135, '2015-09-20', '2018-09-20', 50000, 0, '');
INSERT INTO `contrats` VALUES (171, 142, 50, 0x30332f30392f32303135, '2015-09-03', '2016-09-03', 50000, 0, '');
INSERT INTO `contrats` VALUES (172, 147, 51, 0x31362f322f32303136, '2016-02-16', '2017-02-16', 123, 0, '');
INSERT INTO `contrats` VALUES (173, 148, 52, 0x30362f30312f32303136, '2016-01-14', '2017-01-14', 60000, 0, '');
INSERT INTO `contrats` VALUES (174, 149, 53, 0x30382f30342f32303134, '2014-04-15', '2016-04-15', 25000, 0, '');
INSERT INTO `contrats` VALUES (175, 146, 54, 0x32332f31322f32303135, '2016-01-01', '2017-01-01', 20000, 0, '');
INSERT INTO `contrats` VALUES (177, 145, 55, 0x30382f30322f32303136, '2016-02-08', '2017-01-08', 50000, 0, '');
INSERT INTO `contrats` VALUES (179, 149, 57, 0x30382f30342f32303134, '2014-04-15', '2016-04-15', 25000, 0, '');
INSERT INTO `contrats` VALUES (180, 173, 59, 0x30382f30342f32303134, '2013-02-01', '2022-02-01', 15000, 0, '');
INSERT INTO `contrats` VALUES (181, 172, 60, 0x30312f30392f32303135, '2015-09-01', '2016-09-01', 15000, 0, '');
INSERT INTO `contrats` VALUES (183, 171, 62, 0x32372f30392f32303135, '2015-10-01', '2018-10-01', 15000, 0, '');
INSERT INTO `contrats` VALUES (184, 152, 48, 0x32332f30362f32303136, '2016-03-01', '2017-03-01', 20000, 0, '');
INSERT INTO `contrats` VALUES (185, 170, 61, 0x32392f31302f32303135, '2015-11-02', '2017-11-02', 15000, 0, '');
INSERT INTO `contrats` VALUES (186, 151, 64, 0x31302f30332f32303136, '2016-04-10', '2019-04-10', 250000, 0, '');
INSERT INTO `contrats` VALUES (188, 142, 65, 0x30372f30392f32303135, '2015-09-03', '2016-09-03', 50000, 0, '');

-- --------------------------------------------------------

-- 
-- Structure de la table `locataires`
-- 

CREATE TABLE `locataires` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tel` varchar(20) CHARACTER SET hp8 COLLATE hp8_bin DEFAULT '',
  `mobile` varchar(20) CHARACTER SET hp8 COLLATE hp8_bin DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=ascii COLLATE=ascii_bin AUTO_INCREMENT=66 ;

-- 
-- Contenu de la table `locataires`
-- 

INSERT INTO `locataires` VALUES (46, 'ladjimi ', 0x303338203434203938203635, 0x313233);
INSERT INTO `locataires` VALUES (47, 'boukhezna', 0x303338203434203938203733, 0x313233);
INSERT INTO `locataires` VALUES (48, 'sofiane ', 0x303338203434203938203830, 0x313233);
INSERT INTO `locataires` VALUES (49, 'louse voyage', 0x303338203434203938203837, 0x313233);
INSERT INTO `locataires` VALUES (51, 'ABC banque ', 0x313233, 0x313233);
INSERT INTO `locataires` VALUES (52, 'data distribution  ', 0x313233, 0x313233);
INSERT INTO `locataires` VALUES (54, 'ketfi', 0x303338203434203938203638, 0x313233);
INSERT INTO `locataires` VALUES (55, 'fanit', 0x303338203434203938203730, 0x313233);
INSERT INTO `locataires` VALUES (57, 'TEBANI ', 0x303338203434203938203738, 0x313233);
INSERT INTO `locataires` VALUES (58, 'MADWI', 0x303338203434203938203934, 0x313233);
INSERT INTO `locataires` VALUES (59, 'FASTLINER', 0x303338203433203434203438, 0x3035203532203737203438203537);
INSERT INTO `locataires` VALUES (60, 'EL RAHA EL IKAMA ', 0x303338203434203938203933, 0x313233);
INSERT INTO `locataires` VALUES (61, 'BOULARES ', 0x313233, 0x313233);
INSERT INTO `locataires` VALUES (62, 'FROID', 0x313233, 0x313233);
INSERT INTO `locataires` VALUES (63, 'SARAI ', 0x303338203434203237203832, 0x3035203534203530203933203633);
INSERT INTO `locataires` VALUES (64, 'EURL HOME AND COOK', 0x313233, 0x313233);
INSERT INTO `locataires` VALUES (65, 'BEN SALEM', 0x303338203434203938203837, 0x313233);

-- --------------------------------------------------------

-- 
-- Structure de la table `locaux`
-- 

CREATE TABLE `locaux` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(100) DEFAULT NULL,
  `etage` int(2) NOT NULL,
  `description` varchar(1000) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `longueur` double NOT NULL,
  `largeur` double NOT NULL,
  `surface` double NOT NULL,
  `width` int(100) NOT NULL,
  `height` int(100) NOT NULL,
  `top` int(100) NOT NULL,
  `gauche` varchar(100) NOT NULL,
  `z_index` int(100) NOT NULL,
  `top_desc` int(100) NOT NULL,
  `left_desc` int(100) NOT NULL,
  `font_size` int(100) NOT NULL,
  `display_desc` varchar(50) NOT NULL DEFAULT 'block',
  `type` varchar(10) NOT NULL DEFAULT 'local',
  `lefts` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=latin1 AUTO_INCREMENT=179 ;

-- 
-- Contenu de la table `locaux`
-- 

INSERT INTO `locaux` VALUES (12, 'garage', 1, 0x4c6f63616c20636f6d6d65726369616c, 24.8, 22.6, 440.6, 251, 278, 122, '127', 1, 105, 70, 16, 'block', 'local', '');
INSERT INTO `locaux` VALUES (15, NULL, 1, 0x4c6f63616c20636f6d6d65726369616c, 10, 10, 100, 33, 103, 15, '127', 2, 230, 30, 16, 'none', 'local', '');
INSERT INTO `locaux` VALUES (141, 'louse voyage', 1, '', 0, 0, 0, 188, 60, 128, '386', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (142, 'BEN SALEM', 1, '', 0, 0, 0, 189, 57, 197, '386', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (145, 'kader ', 1, '', 0, 0, 0, 100, 184, 216, '22', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (146, 'ketfi', 1, '', 0, 0, 0, 52, 100, 302, '24', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (147, 'abc banque', 1, '', 0, 0, 0, 231, 141, 261, '348', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (148, 'data distribution', 1, '', 0, 0, 0, 96, 139, 263, '245', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (149, 'nadji', 1, '', 0, 0, 0, 45, 93, 307, '151', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (151, 'EURL HOME AND COOK', 1, '', 0, 0, 0, 226, 100, 21, '353', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (152, 'SOFIANE', 1, '', 0, 0, 0, 53, 98, 21, '292', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (154, 'ladjimi', 1, '', 0, 0, 0, 57, 98, 21, '168', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (155, 'boukhezna', 1, '', 0, 0, 0, 53, 96, 21, '233', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (156, 'GARAGE', 1, '', 0, 0, 0, 246, 130, 127, '130', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (170, 'BOULARES', 2, '', 0, 0, 0, 100, 100, 15, '122', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (171, 'FROID', 2, '', 0, 0, 0, 100, 100, 15, '226', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (172, 'RAHA EL IKAMA', 2, '', 0, 0, 0, 100, 100, 15, '331', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (173, 'FASTLINER', 2, '', 0, 0, 0, 143, 100, 16, '436', 2, 0, 0, 13, 'block', 'bureau', '');
INSERT INTO `locaux` VALUES (175, 'LOCAL ', 2, '', 0, 0, 0, 486, 100, 171, '93', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (176, 'LOCAL ', 2, '', 0, 0, 0, 452, 100, 302, '127', 2, 0, 0, 13, 'block', 'local', '');
INSERT INTO `locaux` VALUES (178, 'SARAI', 2, '', 0, 0, 0, 100, 100, 15, '16', 2, 0, 0, 13, 'block', 'local', '');

-- --------------------------------------------------------

-- 
-- Structure de la table `options`
-- 

CREATE TABLE `options` (
  `etage` varchar(10) NOT NULL,
  `nbr` int(4) NOT NULL,
  `color1` varchar(7) NOT NULL,
  `color2` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `options`
-- 

INSERT INTO `options` VALUES ('RDC', 6, '#1C2BFF', '#3CFF2E');

-- --------------------------------------------------------

-- 
-- Structure de la table `paiement`
-- 

CREATE TABLE `paiement` (
  `contrat` int(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=hp8 COLLATE=hp8_bin;

-- 
-- Contenu de la table `paiement`
-- 

INSERT INTO `paiement` VALUES (1, '2013-01-01');
INSERT INTO `paiement` VALUES (2, '2015-01-01');
INSERT INTO `paiement` VALUES (3, '2014-05-12');
INSERT INTO `paiement` VALUES (4, '2014-01-19');
INSERT INTO `paiement` VALUES (4, '2014-05-19');
INSERT INTO `paiement` VALUES (6, '2013-01-01');
INSERT INTO `paiement` VALUES (8, '2014-01-01');

-- --------------------------------------------------------

-- 
-- Structure de la table `proforma`
-- 

CREATE TABLE `proforma` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `local` int(255) NOT NULL,
  `locataire` varchar(255) COLLATE hp8_bin NOT NULL,
  `date` varchar(10) COLLATE hp8_bin NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `montant` int(200) NOT NULL,
  `autre_declaration` int(100) DEFAULT NULL,
  `fichier` varchar(250) COLLATE hp8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=hp8 COLLATE=hp8_bin AUTO_INCREMENT=6 ;

-- 
-- Contenu de la table `proforma`
-- 

INSERT INTO `proforma` VALUES (1, 1, 0x74657374, 0x382f332f32303135, '2015-03-08', '2016-03-08', 123, 22, '');
INSERT INTO `proforma` VALUES (2, 1, 0x6d6f6e646572, 0x382f332f32303135, '2015-03-08', '2016-03-08', 123, 222, '');
INSERT INTO `proforma` VALUES (3, 1, 0x313233, 0x382f332f32303135, '2015-03-08', '2016-03-08', 123, 123, '');
INSERT INTO `proforma` VALUES (4, 1, 0x6d6f6e7a64, 0x382f332f32303135, '2015-03-08', '2017-03-08', 123, 123, '');
INSERT INTO `proforma` VALUES (5, 12, 0x6b68616c696c, 0x332f332f32303136, '2016-03-25', '2017-04-25', 15000, 20000, '');
